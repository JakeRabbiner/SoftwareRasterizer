#ifndef Vector2_H
#define Vector2_H
#include <cmath>
#include <iostream>

struct Vector2
{
	float x;
	float y;

	Vector2();
	Vector2(float a, float b);
	Vector2 operator*(float b);
	Vector2 operator+(Vector2 x);
	Vector2 operator-(Vector2 x);
	float magnitude();
	float dot(Vector2 temp);
	Vector2 normalize();
	Vector2 perpendicular();
};

float determinant(Vector2 a, Vector2 b);

#endif
