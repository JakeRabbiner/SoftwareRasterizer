#include <iostream>
#include "Color.h"
#include "Raster.h"
using namespace std;



int main() {
	/*
	Raster myRaster(10, 10, White);
	myRaster.drawLine_DDA(5, 0, 0, 0, Red);
	myRaster.writeToPPM();
	*/

	
	Raster myRaster(100, 100, White);

	Triangle2D myTrianlge(Vector2(2, 15), Vector2(72, 10), Vector2(45, 80), Red, Green, Blue); 
	myRaster.drawTrianlge_Barycentric(myTrianlge);

	myRaster.writeToPPM();
	

	
}
